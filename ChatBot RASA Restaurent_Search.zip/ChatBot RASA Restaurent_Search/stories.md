## Generated Story -8153622602520737233
* restaurant_search{"location": "Delhi"}
    - slot{"location": ["Delhi"]}
    - action_location
    - slot{"location": "Delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_cuisine
    - slot{"cuisine": "south indian"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* affirm
    - utter_ask_emailid
* affirm{"emailid": "nareshdogra@rediffmail.com"}
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_search_restaurants
    - utter_goodbye
    - export

