## Generated Story -5728513602621624419
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_cuisine
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": ["chennai"]}
    - action_location
    - slot{"location": "chennai"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* affirm{"emailid": "nareshdogra@rediffmail.com"}
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_search_restaurants
    - utter_goodbye
    - export

## Generated Story -8370390324046552877
* greet
    - utter_greet
* restaurant_search{"location": "Kolkata"}
    - slot{"location": ["Kolkata"]}
    - action_location
    - slot{"location": "Kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_cuisine
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* deny
    - utter_goodbye
    - export

## Generated Story -3489085076360871193
* greet
    - utter_greet
* restaurant_search{"location": "daulatbad"}
    - slot{"location": ["daulatbad"]}
    - action_location
    - utter_default
    - utter_ask_location
* restaurant_search{"location": "Pune"}
    - slot{"location": ["Pune"]}
    - action_location
    - slot{"location": "Pune"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_cuisine
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* deny
    - utter_goodbye
    - export

## Generated Story -3349040613005790112
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "Delhi"}
    - slot{"cuisine": "mexican"}
    - slot{"location": ["Delhi"]}
    - action_location
    - slot{"location": "Delhi"}
    - action_cuisine
    - slot{"cuisine": "mexican"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - export

