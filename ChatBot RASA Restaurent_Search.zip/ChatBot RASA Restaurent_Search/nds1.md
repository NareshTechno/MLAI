## Generated Story -208015394111245513
* greet
    - utter_greet
* restaurant_search{"location": "mumbai"}
    - slot{"location": ["mumbai"]}
    - action_location
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - action_cuisine
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* affirm
    - utter_ask_emailid
* affirm{"emailid": "nareshdogra@rediffmail.com"}
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_search_restaurants
    - utter_goodbye
    - export

