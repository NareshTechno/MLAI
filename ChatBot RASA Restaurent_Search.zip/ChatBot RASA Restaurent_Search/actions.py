from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_nlu.training_data import load_data
from rasa_nlu.config import RasaNLUModelConfig
from rasa_nlu.model import Trainer
from rasa_nlu.model import Metadata, Interpreter

from rasa_core.actions.action import Action
from rasa_core.events import SlotSet
from rasa_core.actions.action import Action
from rasa_core.events import SlotSet


from flask_mail import Mail, Message
from flask import session,flash
from flask import Response
from flask import Flask, render_template, request, redirect, url_for, send_from_directory,jsonify

import json
import re
import os
import numpy as np
import pandas as pd
from pathlib import Path
import zomatopy
import json

class ActionLocation(Action):
	def name(self):
		return 'action_location'
	
	def city_db(self):
		#Database of Tier-1 (X) and Tier-2 (Y) Cities
		folder = Path('./data')
		fname = folder/'city.txt'
		city_list = []
		if os.path.exists(fname):
			with open(fname, 'rb') as f:
				city_df = pd.read_csv(fname, encoding = "utf-8")
				city_list=city_df['City'].str.lower().tolist()
		elif IOError:
			print ("IOError:Severity Critical:Unable to get city list in: ", str(fname))
		
		return city_list
		
	def run(self, dispatcher, tracker, domain):
		slot_value = tracker.get_slot('location')
		if isinstance(slot_value, (list,)):
			if len(slot_value) > 0: 
				slot_value = slot_value[0]

		if slot_value == None:
			slot_value = tracker.latest_message.text	

		if slot_value.lower() not in self.city_db():
			print("city not found")
			print('slot value = ', slot_value.lower())
			print('city_list = ', self.city_db())
			dispatcher.utter_template('utter_wrong_location', tracker)
		else:
			print("city found")
			return [SlotSet('location',slot_value)]

class ActionCuisine(Action):
	def name(self):
		return 'action_cuisine'
	
	def cuisine_db(self):
		#Database of available Cuisines
		cuisine_list=['chinese','mexican','italian','american','south indian','north indian']
		return cuisine_list
	
	def run(self, dispatcher, tracker, domain):
		slot_value = tracker.get_slot('cuisine')

		if slot_value == None:
			slot_value = tracker.latest_message.text	

		if slot_value.lower() not in self.cuisine_db() :
			dispatcher.utter_template('utter_wrong_cuisine', tracker)
		else:
			return [SlotSet('cuisine',slot_value)]

class ActionBudget(Action):
	def name(self):
		return 'action_budget'
	
	def budget_db(self):
		#Database of supported budgets
		budget_list=['Lesser than Rs. 300','Rs. 300 to 700','More than 700']
		return budget_list
		
	def run(self, dispatcher, tracker, domain):
		slot_value = tracker.get_slot('budget')

		if slot_value == None:
			slot_value = tracker.latest_message.text	

		if slot_value not in self.budget_db() :
			dispatcher.utter_template('utter_wrong_budget', tracker)
		else:
			return [SlotSet('budget',slot_value)]
	
class ActionEmailid(Action):        
	def name(self):
		return 'action_emailid'
		
	def run(self, dispatcher, tracker, domain):
		slot_value = tracker.get_slot('emailid')

		if slot_value == None:
			slot_value = tracker.latest_message.text	
		
		pattern = "[a-zA-z0-9]+(\.)?[a-zA-z0-9]*(@)[a-zA-z0-9]+(\.com)$"
		
		if not re.match(pattern, slot_value) :
			dispatcher.utter_template("utter_wrong_emailid",tracker)
		else:
			return [SlotSet('emailid',slot_value)]		
	
class ActionSearchRestaurants(Action):
	
	def name(self):
		return 'action_search_restaurants'
	
	def init_restaurant_search(self):
		config={ "user_key":"7657af8025bf771012673de9bf8b16cb"}
		zomato = zomatopy.initialize_app(config)
		return zomato
	
	def get_location_axis(self, zomato, location):
		location_detail = zomato.get_location(location, 1)
		d1 = json.loads(location_detail)
		latitude =  d1["location_suggestions"][0]["latitude"]
		longitude = d1["location_suggestions"][0]["longitude"]
		
		return(longitude, latitude)
	
	def get_cuisine_id(self, cuisine):
		#Database of available Cuisines
		cuisine_dict = {'american':10,'mexican':15,'chinese':25,'italian':55,'north indian':50,'south indian':85}
		# return cuisine id
		return cuisine_dict.get(cuisine)
	
	def get_budget_range(self, budget):
		# Set low and high values for budget
		budget_low = 1
		budget_high = 999999
		
		if budget == "Lesser than Rs. 300" :
			budget_high = 300
		elif budget == "Rs. 300 to 700" :
			budget_low = 300
			budget_high = 700
		elif budget == "More than 700":
			budget_low = 700
			budget_high = 100000
			
		return (budget_low, budget_high)
	
	def get_top_restaurants(self, zomato, location_axis, cuisine_id, budget_range, top_count):
		longitude, latitude = location_axis
		low, high = budget_range
		result_limit = 100
		
		print('latitude = ', latitude)
		print('longitude = ', longitude)
		print('cuisine_id = ', cuisine_id)
		print('low budget = ', low)
		print('high budget = ', high)
		
		results = zomato.restaurant_search("", latitude, longitude, cuisine_id, result_limit)
		d = json.loads(results)

		response = ""
		count = 0
		
		if d['results_found'] == 0:
			response= " "
		else:
			cnt = 1
			for restaurant in d['restaurants']:
				print( str(cnt) + ".")
				print(" Name    : ", restaurant['restaurant']['name'])
				print(" Address : ", restaurant['restaurant']['location']['address'])
				print("Rating   : ", restaurant['restaurant']['user_rating']['aggregate_rating'])
				print("Avg cost : ", restaurant['restaurant']['average_cost_for_two'])
				if cnt >= 5:
					break				
				cnt += 1

			for restaurant in d['restaurants']:
				if ((restaurant['restaurant']['average_cost_for_two']>=low) and 
					(restaurant['restaurant']['average_cost_for_two']< high))  :
					count = count + 1
					if count > top_count :
						break
					else:
						restaurant_name = restaurant['restaurant']['name']
						restaurant_address = restaurant['restaurant']['location']['address']
						restaurant_rating = restaurant['restaurant']['user_rating']['aggregate_rating']
						restaurant_avg_cost = restaurant['restaurant']['average_cost_for_two']
						
						response = ( response + 
											 str(count) + ". " + 
											 restaurant_name.title() + " in " + 
											 restaurant_address.title() + " has been rated " + 
											 str(restaurant_rating) + 
											 str(restaurant_avg_cost) + ".\n" )

		return response		
	
	def send_mail(self,bodymsg="",emailid=""):
		from flask import Flask
		from flask_mail import Mail, Message

		app1 = Flask(__name__)

		mail_settings = {
			"MAIL_SERVER": 'smtp.gmail.com',
			"MAIL_PORT": 465,
			"MAIL_USE_TLS": False,
			"MAIL_USE_SSL": True,
			"MAIL_USERNAME": 'nareshd.jmu@gmail.com',
			"MAIL_PASSWORD": 'yzixhtvwgazeqofx'
			}

		app1.config.update(mail_settings)
		mail = Mail(app1)

		try:
			with mail_app.app_context():
				msg = Message(subject="List of restaurants",
						sender=app1.config.get("MAIL_USERNAME"),
						recipients=[emailid],
						body=bodymsg)
				mail.send(msg)
		except Exception as e:
			return(str(e))
	
	def run(self, dispatcher, tracker, domain):

		zomato = self.init_restaurant_search()		
		location = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budget = tracker.get_slot('budget')
		emailid = tracker.get_slot('emailid')
		
		location_axis = self.get_location_axis(zomato, location)
		budget_range = self.get_budget_range(budget)
		cuisine_id = str(self.get_cuisine_id(cuisine))
		
		if emailid == None:
			top_count = 5
		else:
			top_count = 10

		response = " "
		response = self.get_top_restaurants(zomato, location_axis, cuisine_id, budget_range, top_count)
	
		if response=="":
			dispatcher.utter_message("Sorry no results found for the criteria")
			dispatcher.utter_template("utter_goodbye", tracker)
		elif emailid == None:
			dispatcher.utter_message(response)
		else:	
			self.send_mail(response, emailid)
			dispatcher.utter_message("Mail Sent to "+emailid+"!!!")
			
		return []	
