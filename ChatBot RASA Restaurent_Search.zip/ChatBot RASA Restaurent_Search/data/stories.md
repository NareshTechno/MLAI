## Story 1
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_searchslot{"location": "Pune"}    
    - slot{"location": ["Pune"]}
    - action_location
    - slot{"location": "Pune"}
	- utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
	- action_cuisine
    - slot{"cuisine": "italian"}	
	- utter_ask_budget
* restaurant_search{"budget": "More than 700"}		
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}	
    - action_search_restaurants
    - utter_senton_email	
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart
    
## Story 2
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location    
* restaurant_search    	
    - slot{"location": ["Delhi"]}
    - action_location
    - slot{"location": "Delhi"}	
	- utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
	- action_cuisine	
    - slot{"cuisine": "italian"}
	- utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}	
    - action_search_restaurants
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart

## Story 3
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "Mumbai"}
    - slot{"cuisine": "mexican"}
    - slot{"location": ["Mumbai"]}
	- action_cuisine	
    - slot{"cuisine": "mexican"}	
    - action_location
    - slot{"location": "Mumbai"}
	- utter_ask_budget
* restaurant_search{"budget": "Rs. 300 to 700"}
    - slot{"budget": "Rs. 300 to 700"}
	- action_budget
    - slot{"budget": "Rs. 300 to 700"}		
    - action_search_restaurants	
    - utter_senton_email
* affirm
    - utter_ask_emailid
* affirm{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart
 
## Story 4 - ## Generated Story -3349040613005790112
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "Delhi"}
    - slot{"cuisine": "mexican"}
    - slot{"location": ["Delhi"]}
    - action_cuisine
    - slot{"cuisine": "mexican"}	
    - action_location
    - slot{"location": "Delhi"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart	
	

## Story 5
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}	
    - slot{"location": ["Bangalore"]}
    - action_location
    - slot{"location": "Bangalore"}	
	- utter_ask_cuisine	
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
	- action_cuisine
    - slot{"cuisine": "north indian"}
	- utter_ask_budget	
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart

* restaurant_search{"location": "Bangalore"}
    - slot{"location": ["Bangalore"]}
    - action_location
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_cuisine
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* restaurant_search{"budget": "Rs. 300 to 700"}
    - slot{"budget": "Rs. 300 to 700"}
    - action_budget
    - slot{"budget": "Rs. 300 to 700"}
    - action_search_restaurants
    - utter_senton_email
* restaurant_search
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_emailid	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_search_restaurants
    - utter_goodbye
    - action_restart
	
	
## Story 6
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian"}   
    - slot{"cuisine": "italian"}
	- action_cuisine
    - slot{"cuisine": "italian"}	
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": ["Bangalore"]}
	- action_location
    - slot{"location": "Bangalore"}
	- utter_ask_budget	
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
	- action_budget
    - slot{"budget": "More than Rs. 700"}	
    - action_search_restaurants
    - utter_senton_email
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart


## Story 7
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_search{"location": "Kolkata"}
    - slot{"location": ["Kolkata"]}
    - action_location
    - slot{"location": "Kolkata"}
	- utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
	- action_cuisine
    - slot{"cuisine": "north indian"}
    - slot{"location": "Kolkata"}
    - action_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - action_budget	
    - utter_senton_email
* affirm
    - utter_ask_emailid
* restaurant_search
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid	
    - action_search_restaurants
    - utter_goodbye
    - action_restart

## Story 8
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_search{"location": "Kolkata"}
    - slot{"location": ["Kolkata"]}
    - action_location
    - slot{"location": "Kolkata"}
	- utter_ask_cuisine	
* restaurant_search
    - slot{"cuisine": "chinese"}
	- action_cuisine
    - slot{"cuisine": "chinese"}	
	- utter_ask_budget	
* restaurant_search{"budget": "Rs. 300 to 700"}
    - slot{"budget": "Rs. 300 to 700"}
	- action_budget
    - slot{"budget": "Rs. 300 to 700"}	
    - action_search_restaurants
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart
	
## Story 9
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_search    
    - slot{"location": "daulatbad"}
	- action_location	
	- utter_default
	- utter_ask_location	
* restaurant_searchslot{"location": "Pune"}    
    - slot{"location": ["Pune"]}
	- action_location	
    - slot{"location": "Pune"}
	- utter_ask_cuisine	
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
	- action_cuisine
    - slot{"cuisine": "italian"}	
	- utter_ask_budget
* restaurant_search{"budget": "More than 700"}	
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}		
    - action_search_restaurants
    - utter_senton_email	
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart	

## Story 10 - user enters wrong cuisine - e.g. "notacuisine"
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_searchslot{"location": "Pune"}    
    - slot{"location": ["Pune"]}
    - action_location	
    - slot{"location": "Pune"}
	- utter_ask_cuisine
* restaurant_search
	- action_cuisine
	- utter_default
	- utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
	- action_cuisine
    - slot{"cuisine": "italian"}	
	- utter_ask_budget
* restaurant_search{"budget": "More than 700"}		
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}		
    - action_search_restaurants
    - utter_senton_email	
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart
	
## Story 10 - user enters wrong budget - e.g. "invalidbudget"
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_searchslot{"location": "Pune"}    
    - slot{"location": ["Pune"]}
    - action_location	
    - slot{"location": "Pune"}	
	- utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
	- action_cuisine	
    - slot{"cuisine": "italian"}	
	- utter_ask_budget	
* restaurant_search	
    - slot{"budget": "invalidbudget"}	
	- action_budget
	- utter_default
	- utter_ask_budget
* restaurant_search	
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}		
    - action_search_restaurants
    - utter_senton_email	
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid    
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart	

## Story 11
* greet
    - utter_greet
* restaurant_search
	- utter_ask_location
* restaurant_search{"location": "Jammu"}    
    - slot{"location": ["jammu"]}
    - action_location	
    - slot{"location": "jammu"}	
	- utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
	- action_cuisine
    - slot{"cuisine": "italian"}	
	- utter_ask_budget	
* restaurant_search	
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}		
    - action_search_restaurants
    - utter_senton_email	
* affirm
    - utter_ask_emailid
* restaurant_search
	- action_emailid    
	- utter_default
	- utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart	

## Story 12 - Generated Story -5728513602621624419
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_cuisine
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": ["chennai"]}
    - action_location
    - slot{"location": "chennai"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* affirm{"emailid": "nareshdogra@rediffmail.com"}
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}
    - action_search_restaurants
    - utter_goodbye
    - action_restart
	
## Story 13 - Generated Story -3489085076360871193
* greet
    - utter_greet
* restaurant_search{"location": "daulatbad"}
    - slot{"location": ["daulatbad"]}
    - action_location
    - utter_default
    - utter_ask_location
* restaurant_search{"location": "Pune"}
    - slot{"location": ["Pune"]}
    - action_location
    - slot{"location": "Pune"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_cuisine
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_budget
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart

## Story 14
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "Delhi"}
    - slot{"cuisine": "italian"}
    - slot{"location": ["Delhi"]}
	- action_cuisine	
    - slot{"cuisine": "italian"}	
    - action_location
    - slot{"location": "Delhi"}
	- utter_ask_budget
* restaurant_search{"budget": "Rs. 300 to 700"}
    - slot{"budget": "Rs. 300 to 700"}
	- action_budget
    - slot{"budget": "Rs. 300 to 700"}		
    - action_search_restaurants	
    - utter_senton_email
* affirm
    - utter_ask_emailid
* affirm{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart

## Story 15
* greet
    - utter_greet
* restaurant_search{"cuisine": "north indian", "location": "Mumbai"}
    - slot{"cuisine": "north indian"}
    - slot{"location": ["Mumbai"]}
	- action_cuisine	
    - slot{"cuisine": "north indian"}
	- action_location
    - slot{"location": "Mumbai"}
	- utter_ask_budget
* restaurant_search{"budget": "Rs. 300 to 700"}
    - slot{"budget": "Rs. 300 to 700"}
	- action_budget
    - slot{"budget": "Rs. 300 to 700"}		
    - action_search_restaurants	
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart
	
## Story 16
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian", "location": "Kochi"}
    - slot{"cuisine": "north indian"}
    - slot{"location": ["Kochi"]}
	- action_cuisine
    - slot{"cuisine": "north indian"}
    - action_location	
    - slot{"location": "Kochi"}
	- utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs. 300"}
    - slot{"budget": "Lesser than Rs. 300"}
	- action_budget
    - slot{"budget": "Lesser than Rs. 300"}		
    - action_search_restaurants	
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart

## Story 16
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "Delhi", "budget": "More than 700"}
    - slot{"cuisine": "italian"}
    - slot{"location": ["Delhi"]}
    - slot{"budget": "Rs. 300 to 700"}	
	- action_cuisine	
    - slot{"cuisine": "italian"}	
    - action_location
    - slot{"location": "Delhi"}
    - slot{"budget": "Rs. 300 to 700"}
	- action_budget	
    - slot{"budget": "Rs. 300 to 700"}		
    - action_search_restaurants	
    - utter_senton_email
* affirm
    - utter_ask_emailid
* affirm{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart

## Story 17
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "Delhi", "budget": "More than 700"}
    - slot{"cuisine": "italian"}
    - slot{"location": ["Delhi"]}
    - slot{"budget": "Rs. 300 to 700"}	
	- action_cuisine	
    - slot{"cuisine": "italian"}	
    - action_location
    - slot{"location": "Delhi"}
    - slot{"budget": "Rs. 300 to 700"}
	- action_budget	
    - slot{"budget": "Rs. 300 to 700"}		
    - action_search_restaurants	
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart

## Story 18
* greet
    - utter_greet
* restaurant_search{"location": "Kochi"}
    - slot{"location": ["Kochi"]}
    - action_location	
    - slot{"location": "Kochi"}
	- utter_ask_cuisine	
* restaurant_search{"cuisine": "south indian"}	
    - slot{"cuisine": "south indian"}
	- action_cuisine
    - slot{"cuisine": "south indian"}	
	- utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs. 300"}
    - slot{"budget": "Lesser than Rs. 300"}
	- action_budget
    - slot{"budget": "Lesser than Rs. 300"}		
    - action_search_restaurants	
    - utter_senton_email
* deny
    - utter_goodbye
    - export	

## Story 19
* greet
    - utter_greet
* restaurant_search{"location": "Kochi", "budget": "More than 700"}
    - slot{"location": ["Kochi"]}
    - slot{"budget": "More than 700"}	
	- action_location
    - slot{"location": "Kochi"}
	- action_budget	
    - slot{"budget": "More than 700"}
	- utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
	- action_cuisine
    - slot{"cuisine": "american"}
    - action_search_restaurants	
    - utter_senton_email
* deny
    - utter_goodbye
    - action_restart

## Story 20
* greet
    - utter_greet
* restaurant_search{"cuisine: "south indian","location": "Amritsar"}
	- slot{"cuisine": "south indian"}
	- slot{"location": ["Amritsar"]}	
	- action_cuisine
	- slot{"cuisine": "south indian"}
	- action_location		
	- slot{"location": "Amritsar"}   
	- utter_ask_budget
* restaurant_search{"budget": "More than 700"}	
    - slot{"budget": "More than 700"}	
	- action_budget
    - slot{"budget": "More than 700"}		
    - action_search_restaurants
    - utter_senton_email	
* affirm
    - utter_ask_emailid
* restaurant_search{"emailid": "nareshdogra@rediffmail.com"}	
    - slot{"emailid": "nareshdogra@rediffmail.com"}
	- action_emailid
    - slot{"emailid": "nareshdogra@rediffmail.com"}	
    - action_search_restaurants
    - utter_goodbye
    - action_restart	