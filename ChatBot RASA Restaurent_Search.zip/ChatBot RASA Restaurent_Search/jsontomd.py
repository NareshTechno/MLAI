from rasa_nlu.training_data import load_data

# not part of original file
# included here to convert training data file from json into markdown md format
output_md_file = 'training.md'
with open(output_md_file,'w') as f:
	f.write(load_data('data/data.json').as_markdown())
